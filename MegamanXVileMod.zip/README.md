# Overview
Megaman X Vile survivor for Risk Of Rain 2, time to show that i can hunt some maverick monsters better than X!
This mod contais some SFX for shots and voice for some skills!

# Instructions for install:
place the dll in your plugins folder or extract to a folder inside plugins.


# Screenshots
![](https://i.imgur.com/U3deejK.png)
![](https://i.imgur.com/geuxrOl.png)
![](https://i.imgur.com/E4OS5hR.png)
![](https://i.imgur.com/q4egApU.png)
![](https://i.imgur.com/hnDgSRN.png)

# Feedback
Hey, if you want to talk, give me a hint for this mod you can DM me on discord, but sorry for my bad english and i hope you enjoy!

# Discord
BLKNeko#8448 (i'm also in the RoR2 modding community, they helped me a lot)

#KNOW ISSUES:
- Golden Needler is not working for no reason.


#Skins:
To set the skin you want you need to edit the .cfg file from this mod: this file can be found on "Risk of Rain 2\BepInEx\config" after you run this mod at least once.
Vile Default Skin = 0 // VileMK-II Skin = 1
Just change the SkinIndex value to the skin you whant, save, and play.

![](https://i.imgur.com/zXoIGe5.png)



# Changelog
V 1.0.0 Posted

# Special Thanks
- The RoR2 Modding Community
- My Friends
- My Family
- eXcella who made the MKII skin and the idle animation!!

# Donations
-Please, remember this mod is FREE and aways will be, i made this hoping that you would enjoy and have fun !
-If you want to support me this is the link
https://www.paypal.com/donate?hosted_button_id=JU57WD5QVUC2Y

#CHECK OUT MY OTHER MODS !
-Axl from Megaman X
https://thunderstore.io/package/BLKNeko/MegamanAXLMod/
-Zero from Megaman X
https://thunderstore.io/package/BLKNeko/MegamanXZeroMod/
-X from Megaman X
https://thunderstore.io/package/BLKNeko/MegamanXMod/

#CREDITS
VILE MODEL ORIGINAL CREDITS!!!
https://drive.google.com/drive/folders/1yU_VyM82efz_ehx6J-IAgAUDmSqDdUJg
